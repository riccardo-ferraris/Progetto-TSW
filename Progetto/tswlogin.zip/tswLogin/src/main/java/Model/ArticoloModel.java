package Model;

import java.sql.SQLException;

public abstract class ArticoloModel {
	protected abstract Articolo doRetrieveByKey(long seriale) throws SQLException, ClassNotFoundException;
}
